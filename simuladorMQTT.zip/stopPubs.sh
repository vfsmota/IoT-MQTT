#!/bin/bash
killall python3